# MACRO3AS2
Applied Macroeconomic Modelling report
