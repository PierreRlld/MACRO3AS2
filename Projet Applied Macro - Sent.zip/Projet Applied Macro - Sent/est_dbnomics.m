[my_mat,my_table,T]=call_dbnomics('OECD/QNA/FRA.B1_GE.VIXOBSA.Q','OECD/QNA/FRA.B1_GE.DNBSA.Q')
plot(T,my_mat(:,2))